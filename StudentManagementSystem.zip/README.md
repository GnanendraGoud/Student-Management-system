# 🎓 Student Management System (Java + MySQL Project)

A console-based Student Management System built using Java, JDBC, and MySQL.

## Features
- Add, view, update, delete student records
- JDBC connectivity
- OOP principles (Encapsulation, Abstraction)
- CRUD operations

## Setup Instructions
1. Import `student_db.sql` into MySQL
2. Edit `DBConnection.java` to set username and password
3. Compile:
   ```bash
   javac -cp "lib/mysql-connector-java-8.0.xx.jar" -d bin src/*.java
   ```
4. Run:
   ```bash
   java -cp "bin:lib/mysql-connector-java-8.0.xx.jar" Main
   ```

## Author
**Gnanendra Goud**
