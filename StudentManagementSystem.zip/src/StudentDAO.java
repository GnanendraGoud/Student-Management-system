import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public boolean addStudent(Student s) {
        String sql = "INSERT INTO students (name, roll_number, email, contact_number, course) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getRollNumber());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getContactNumber());
            ps.setString(5, s.getCourse());
            int rows = ps.executeUpdate();
            if(rows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if(rs.next()) s.setStudentId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException ex) {
            System.err.println("Error adding student: " + ex.getMessage());
        }
        return false;
    }

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT student_id, name, roll_number, email, contact_number, course FROM students ORDER BY student_id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Student s = new Student();
                s.setStudentId(rs.getInt("student_id"));
                s.setName(rs.getString("name"));
                s.setRollNumber(rs.getString("roll_number"));
                s.setEmail(rs.getString("email"));
                s.setContactNumber(rs.getString("contact_number"));
                s.setCourse(rs.getString("course"));
                list.add(s);
            }
        } catch (SQLException ex) {
            System.err.println("Error fetching students: " + ex.getMessage());
        }
        return list;
    }

    public Student getStudentById(int id) {
        String sql = "SELECT student_id, name, roll_number, email, contact_number, course FROM students WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Student s = new Student();
                    s.setStudentId(rs.getInt("student_id"));
                    s.setName(rs.getString("name"));
                    s.setRollNumber(rs.getString("roll_number"));
                    s.setEmail(rs.getString("email"));
                    s.setContactNumber(rs.getString("contact_number"));
                    s.setCourse(rs.getString("course"));
                    return s;
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error fetching student: " + ex.getMessage());
        }
        return null;
    }

    public boolean updateStudent(Student s) {
        String sql = "UPDATE students SET name = ?, roll_number = ?, email = ?, contact_number = ?, course = ? WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getRollNumber());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getContactNumber());
            ps.setString(5, s.getCourse());
            ps.setInt(6, s.getStudentId());
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException ex) {
            System.err.println("Error updating student: " + ex.getMessage());
        }
        return false;
    }

    public boolean deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE student_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException ex) {
            System.err.println("Error deleting student: " + ex.getMessage());
        }
        return false;
    }
}