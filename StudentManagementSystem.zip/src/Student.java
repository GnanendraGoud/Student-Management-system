public class Student {
    private int studentId;
    private String name;
    private String rollNumber;
    private String email;
    private String contactNumber;
    private String course;

    public Student() {}

    public Student(String name, String rollNumber, String email, String contactNumber, String course) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.email = email;
        this.contactNumber = contactNumber;
        this.course = course;
    }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRollNumber() { return rollNumber; }
    public void setRollNumber(String rollNumber) { this.rollNumber = rollNumber; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    @Override
    public String toString() {
        return String.format("ID: %d | Name: %s | Roll: %s | Email: %s | Contact: %s | Course: %s",
                studentId, name, rollNumber, email, contactNumber, course);
    }
}