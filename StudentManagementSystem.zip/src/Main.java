import java.util.List;
import java.util.Scanner;

public class Main {
    private static final StudentDAO dao = new StudentDAO();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Student Management System ===");
        boolean running = true;
        while (running) {
            showMenu();
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1": createStudent(); break;
                case "2": listStudents(); break;
                case "3": viewStudent(); break;
                case "4": updateStudent(); break;
                case "5": deleteStudent(); break;
                case "0": running = false; break;
                default: System.out.println("Invalid option. Try again."); break;
            }
        }
        System.out.println("Exiting. Thanks!");
        sc.close();
    }

    private static void showMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Add Student");
        System.out.println("2. List All Students");
        System.out.println("3. View Student by ID");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("0. Exit");
        System.out.print("Choose: ");
    }

    private static void createStudent() {
        System.out.println("\n-- Add Student --");
        System.out.print("Name: "); String name = sc.nextLine();
        System.out.print("Roll Number: "); String roll = sc.nextLine();
        System.out.print("Email: "); String email = sc.nextLine();
        System.out.print("Contact Number: "); String contact = sc.nextLine();
        System.out.print("Course: "); String course = sc.nextLine();

        Student s = new Student(name, roll, email, contact, course);
        boolean ok = dao.addStudent(s);
        if (ok) System.out.println("Student added with ID: " + s.getStudentId());
        else System.out.println("Failed to add student.");
    }

    private static void listStudents() {
        System.out.println("\n-- Students List --");
        List<Student> list = dao.getAllStudents();
        if (list.isEmpty()) System.out.println("No records found.");
        else list.forEach(System.out::println);
    }

    private static void viewStudent() {
        System.out.print("\nEnter student ID: ");
        int id = Integer.parseInt(sc.nextLine());
        Student s = dao.getStudentById(id);
        if (s == null) System.out.println("Student not found.");
        else System.out.println(s);
    }

    private static void updateStudent() {
        System.out.print("\nEnter ID to update: ");
        int id = Integer.parseInt(sc.nextLine());
        Student s = dao.getStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.println("Leave blank to keep current value.");

        System.out.print("Name (" + s.getName() + "): "); String name = sc.nextLine(); if (!name.isEmpty()) s.setName(name);
        System.out.print("Roll Number (" + s.getRollNumber() + "): "); String roll = sc.nextLine(); if (!roll.isEmpty()) s.setRollNumber(roll);
        System.out.print("Email (" + s.getEmail() + "): "); String email = sc.nextLine(); if (!email.isEmpty()) s.setEmail(email);
        System.out.print("Contact Number (" + s.getContactNumber() + "): "); String contact = sc.nextLine(); if (!contact.isEmpty()) s.setContactNumber(contact);
        System.out.print("Course (" + s.getCourse() + "): "); String course = sc.nextLine(); if (!course.isEmpty()) s.setCourse(course);

        boolean ok = dao.updateStudent(s);
        if (ok) System.out.println("Updated successfully.");
        else System.out.println("Update failed.");
    }

    private static void deleteStudent() {
        System.out.print("\nEnter ID to delete: ");
        int id = Integer.parseInt(sc.nextLine());
        boolean ok = dao.deleteStudent(id);
        if (ok) System.out.println("Deleted successfully.");
        else System.out.println("Delete failed.");
    }
}